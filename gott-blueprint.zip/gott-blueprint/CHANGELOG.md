# Changelog

All notable changes to GOTT Protocol blueprint will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-04-17

### Added
- Initial blueprint documentation
- README with project overview
- Single-file BLUEPRINT.md for quick reference
- Full documentation structure (docs/00-14)
  - 00: Vision & Mission
  - 01: Market Analysis
  - 02: Competitive Landscape
  - 03: Protocol Architecture
  - 04: Smart Contract Specifications
  - 05: Scam Detection Engine
  - 06: Cleanup Mining Mechanism
  - 07: Tokenomics
  - 08: Treasury Management
  - 09: Roadmap 6 Bulan
  - 10: Launch Strategy
  - 11: Marketing Playbook
  - 12: DAO Governance
  - 13: Risk Register
  - 14: Legal Considerations
- MIT License
- Project structure placeholders (contracts/, frontend/, scripts/)

### Architecture Decisions
- Three-layer protocol design (Cleanup Engine + Mining + DAO)
- BSC primary, EVM expansion future
- No IDO / No Presale — mining-based distribution
- Indonesia-first positioning
- Progressive decentralization (multisig → DAO over 12-18 months)

### Tokenomics
- Max supply: 1,000,000,000 GOTT
- Allocation: Mining 50%, LP 20%, DAO 15%, Team 10%, Marketing 5%
- Emission: 24 months, halving per 6 months
- Initial circulating: 75M (7.5%)

## [Unreleased]

### Planned
- Smart contract implementation (Solidity)
- Backend API development
- Frontend web app
- Testnet deployment
- Audit engagement
- Mainnet launch
